from tornado import web,ioloop,httpserver

#主页面
class MainPageHandler(web.RequestHandler):
    def get(self,*args,**kwargs):
        self.write('我笑死了')

#路由系统
app = web.Application(
    [
        (r'/',MainPageHandler),
    ]
)

if __name__=='__main__':
    #前台 socket
    htpp_server = httpserver.HTTPServer(app)
    htpp_server.listen(8000)
    ioloop.IOLoop.current().start()
