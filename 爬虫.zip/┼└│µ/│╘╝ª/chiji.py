# import requests
# import json
#
# headers = {
#     'user-agent' : 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36'
# }
# encoding = 'utf-8'
# base_data = requests.get('https://gp.qq.com/zlkdatasys/data_zlk_jxbk.json',headers=headers)
#
# print(base_data.text)
#

import io
import re
import requests
encoding = 'utf-8'
data = open('D:\爬虫\项目\吃鸡\data_zlk_jxbk.json')
data = data.read()
print(type(data))
print(data)
urls = re.findall('game.gtimg.cn(.*?).jpg',data)
for url in urls:
   # print(url)
    url = 'http://'+'\/game.gtimg.cn'+url+'.jpg'
    res = requests.get(url).content
    name = url.split('.')[-1]
    with open('D:\爬虫\项目\吃鸡\picture'+name+'.jpg','wb') as f:
        f.write(res)
