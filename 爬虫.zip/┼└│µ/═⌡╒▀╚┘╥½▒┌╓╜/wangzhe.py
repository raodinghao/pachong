import requests
import json

headers = {
    'user-agent' : 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36'
}

base_data = requests.get('https://game.gtimg.cn/images/lol/act/img/js/heroList/hero_list.js',headers=headers)
response = base_data.text
# print(response)

data_list = json.loads(response)
print(data_list)
for i in data_list['hero']:
    print(i)
# p = 1
# for i in data_list:
#     print("%d"%p+i['cname'])
#     p+=1
# for data in data_list:
#     #print(data)
#     ename = data['ename']
#     cname = data['cname']
#     try:
#         skin_name = data['skin_name'].split('|')
#     except Exception as e:
#         print(e)
#     print(ename,cname,skin_name)
#     for i in range(1,len(skin_name)+1):
#         url = 'http://game.gtimg.cn/images/yxzj/img201606/skin/hero-info/{}/{}-bigskin-{}.jpg'.format(ename,ename,i)
#         res = requests.get(url).content
#         with open('D:\爬虫\项目\王者荣耀壁纸' + '/' +cname+'-'+skin_name[i-1]+'.jpg','wb') as f:
#             f.write(res)
#
