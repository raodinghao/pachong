import requests
import re
import parsel
import os
headers = {
   'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36'
}

for i in range(1,2):
    print("=================正在爬取{}页数据==================".format(i))
    resonpose = requests.get('http://www.win4000.com/meinvtag26_{}.html'.format(i),headers=headers)
    resonpose.encoding = resonpose.apparent_encoding #自动识别响应字体
    data  = resonpose.text
    # print(data)
    html_data = parsel.Selector(data)
    print(html_data)
    data_list = html_data.xpath('//div[@class="Left_bar"]//ul//li/a/@href|//div[@class="Left_bar"]//ul//li/a/img/@title').extract() #用xpath选择相册的地址和标题
    print(data_list)
    data_list = [data_list[i:i+2] for i in range(0,len(data_list),2)] #使用列表推导式对列表进行分组


    for alist in data_list:
        html_url = alist[0]
        file_name = alist[1]

        #创建图片文件夹
        if not os.path.exists('img\\'+file_name):
            os.mkdir('img\\'+file_name)
        print("正在下载：",file_name)

        #发送详情页面请求，解析出总页数
        resonpose_2 = requests.get(html_url,headers=headers).text
        html_2 = parsel.Selector(resonpose_2)

        page_num = html_2.xpath('//div[@class="ptitle"]//em/text()').extract_first() #图片张数



        for url in range(1,int(page_num)+1):
            #构建相册翻页url地址
            url_list = html_url.split('.')
            all_url = url_list[0]+ '.' + url_list[1] + '.' + url_list[2] + '_' + str(url) + '.' + url_list[3]

            print(all_url)

            #发送详情页面请求，解析详情页面的图片url地址
            res3 = requests.get(all_url,headers=headers).text
            html_3 = parsel.Selector(res3)
            # print("============",html_3)
            img_url = html_3.xpath('//div[@class="pic_main"]//div[@class="pic-meinv"]//img/@data-original').extract_first()
            print(img_url)

            #请求图片地址
            img_data = requests.get(img_url,headers=headers).content

            #图片的文件名
            img_name = str(url)+'.jpg'

            #保存数据
            with open('img\\{}\\'.format(file_name)+img_name,'wb') as f:
                f.write(img_data)
