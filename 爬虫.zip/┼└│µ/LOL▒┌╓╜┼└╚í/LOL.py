import requests
import json
import parsel
import re
import time

proxies={
'http':'139.224.233.103:8118'
}

headers = {
    'user-agent' : 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36'
}

base_data = requests.get('https://game.gtimg.cn/images/lol/act/img/js/heroList/hero_list.js',headers=headers,proxies=proxies)
response = base_data.text
# print(response)

data_list = json.loads(response)
# print(data_list)
# for i in data_list['hero']:
#     print(i)
hero_id = []
for hero in data_list['hero']:
    print('正在爬取{}，heroID:{}'.format(hero['name'],hero['heroId']))
    if int(hero['heroId']) < 52:
        continue
    hero_id.append(hero['heroId'])
    select_au = requests.get(hero['selectAudio']).content
    ban_au = requests.get(hero['banAudio']).content
    name = hero['title']
    with open('D:\爬虫\项目\LOL壁纸爬取\音频' + '/' + name + '_'+ 'select_AU'+ '.ogg','wb') as f:
        f.write(select_au)
    with open('D:\爬虫\项目\LOL壁纸爬取\音频' + '/' + name + '_'+ 'ban_AU'+ '.ogg','wb') as f:
        f.write(ban_au)
    url = 'http://game.gtimg.cn/images/lol/act/img/js/hero/{}.js'.format(hero['heroId'])
    base_data = requests.get(url, headers=headers)
    base_data = base_data.text
    response = json.loads(base_data)
    print(response['skins'])
    main_img = []
    load_img2 = []
    source_img = []
    for ing in response['skins']:
        if ing['mainImg']:
            main_img.append(ing['mainImg'])
            load_img2.append(ing['loadingImg'])
            source_img.append(ing['sourceImg'])
        else:
            break
    print(main_img)
    print(load_img2)
    print(source_img)
    p = 0
    for load_img in main_img:
        p+=1
        res = requests.get(load_img).content
        with open('D:\爬虫\项目\LOL壁纸爬取\图片\mainimg' + '/' + name + '_' + '{}'.format(p) + '.jpg','wb') as f:
            f.write(res)
        time.sleep(0.5)
    p = 0
    for load_img in load_img2:
        p+=1
        res = requests.get(load_img).content
        with open('D:\爬虫\项目\LOL壁纸爬取\图片\loadimg' + '/' + name + '_' + '{}'.format(p) + 'c' + '.jpg','wb') as f:
            f.write(res)
        time.sleep(0.5)
    p = 0
    for load_img in source_img:
        p+=1
        res = requests.get(load_img).content
        with open('D:\爬虫\项目\LOL壁纸爬取\图片\sourceimg' + '/' + name + '_' + '{}'.format(p) + 's' + '.jpg','wb') as f:
            f.write(res)
        time.sleep(0.5)
print(hero_id)

