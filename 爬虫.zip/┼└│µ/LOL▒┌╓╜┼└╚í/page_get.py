import requests
import json
import parsel
from lxml import etree
import lxml
import json

headers = {
    'user-agent' : 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36'
}

url = 'http://game.gtimg.cn/images/lol/act/img/js/hero/{}.js'.format(id)
base_data = requests.get(url,headers=headers)
base_data = base_data.text
response = json.loads(base_data)
print(response['skins'])
bgimg = []
for ing in response['skins']:
    bgimg.append(ing['mainImg'])
print(bgimg)
# base_data.encoding="utf-8"
# response = parsel.Selector(str(base_data))
# print(response)
#
# title = response.xpath('//*[@id="navbar"]/li/a').extract()
# print(title)