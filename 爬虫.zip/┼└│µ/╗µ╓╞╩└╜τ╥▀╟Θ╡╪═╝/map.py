import requests
import json
import jsonpath
from pyecharts.charts import Map,Geo

headers = {
    'User-Agent' : 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36'
}

response = requests.get('https://api.inews.qq.com/newsqa/v1/automation/foreign/country/ranklist',headers=headers)
data = json.loads(response.text)
print(data['data'][0]['name'])
print(data)
name = jsonpath.jsonpath(data,'$..name')
print(name)
confirm = jsonpath.jsonpath(data,'$..confirm')
print(confirm)

# data_list = zip(name,confirm)
# print(list(data_list))
# map = Map().add(series_name="世界疫情分布",
#                 data_pair= data_list,
#                 maptype="world",
#                 is_map_symbol_show=False,
#
# )
#
# map.render('世界疫情分布情况.html')
