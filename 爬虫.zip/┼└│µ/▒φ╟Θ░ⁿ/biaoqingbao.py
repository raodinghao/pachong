import requests
import re

response = requests.get('https://www.fabiaoqing.com/bqb/detail/id/54024.html')
data = response.text
# print(data)

urls = re.findall('http://(.*?).gif',data)

i = 0
for url in urls:
    i += 1
    url = 'http://{}.gif'.format(url)
    res = requests.get(url)
    name = str(i)
    with open('D:\爬虫\项目\表情包'+ '/' + name+'.gif','wb') as f:
        f.write(res.content)
