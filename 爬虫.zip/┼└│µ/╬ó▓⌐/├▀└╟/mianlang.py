import requests
import json
import pprint

def download_onepage(curl):
    url = curl
    response = requests.get(url)
    data = response.json()
    # pprint.pprint(data)

    text = data['data']['cards']

    for card in text:
        mblog = card.get('mblog')
        if mblog:
            source = mblog['source']
            text = mblog['text']
            created_at = mblog['created_at']
            print(source,text,created_at)

download_onepage('https://m.weibo.cn/api/container/getIndex?uid=1768167034&luicode=10000011&lfid=231093_-_selffollowed&type=uid&value=1768167034&containerid=1076031768167034')
download_onepage('https://m.weibo.cn/api/container/getIndex?uid=1267224222&t=0&luicode=10000011&lfid=100103type%3D1%26q%3D%E7%9C%A0%E7%8B%BC&type=uid&value=1267224222&containerid=1076031267224222')
download_onepage('https://m.weibo.cn/api/container/getIndex?uid=1267224222&t=0&luicode=10000011&lfid=100103type%3D1%26q%3D%E7%9C%A0%E7%8B%BC&type=uid&value=1267224222&containerid=1076031267224222&since_id=4492597471444953')
