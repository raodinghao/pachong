cnt = 0
res = 0

for a in range(121,131):
    for b in range(121,131):
        for c in range(121,131):
            if (a*a + b*b == c*c):
                cnt+=1
                res+=c

print("个数：{}，总和{}".format(cnt,res))